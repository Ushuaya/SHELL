//
//  exec.h
//  
//
//  Created by Ivan on 07.12.2020.
//

#ifndef exec_h
#define exec_h

#include <stdio.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>
//#include <signal.h>
#include <math.h>
#include "syn.h"
#include "tree.h"


int execute(tree run_tree);

#endif /* exec_h */
